import { useState } from "react";
import { doRegister } from './api';
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function RegisterForm() {
    const navigate = useNavigate();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [username, setUsername] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
    
        const { success, data } = await doRegister(email, password, username);
        if (success) {
            navigate("/login", { state: { message: data } });
        } else {
            toast(data);
        }
    }
    

    return (
        <div className="container form-group mt-5">
            <h2>Registration Form</h2>
            <form onSubmit={handleSubmit}>


            <div class="form-group">
                    <label for="email2">Email address</label>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-control" id="email2" aria-describedby="emailHelp" placeholder="Enter email"/>
                </div>
                
                <div class="form-group">
                    <label for="password2">Password</label>
                    <input type="password"  value={password} onChange={(e) => setPassword(e.target.value)} className="form-control" id="password2" placeholder="Password"/>
                </div>

                <div class="form-group">
                    <label for="password2">Username</label>
                    <input type="text"   value={username} onChange={(e) => setUsername(e.target.value)} className="form-control" id="password2" placeholder="Password"/>
                </div><br/>
                <button type="submit" className="btn btn-info">Register</button>
            </form>
        </div>
    )
}

export default RegisterForm;
