
import { RouterProvider} from "react-router-dom";
import { createBrowserRouter } from 'react-router-dom';

import Navigation from './Navigation';
import Page404 from './Page404';
import LoginForm from './LoginForm';
import Posts from './Posts';
import MyPosts from './MyPosts';
import RegisterForm from "./RegisterForm";
import CreateForm from "./CreateForm";
export default function App(){

  const routes = createBrowserRouter([
    {
      path: "/",
      element: <Navigation/>,
      errorElement:<Page404/>,
      children: [
        {
          path: "register",
          element:< RegisterForm/>
        },
        {
          path: "login",
          element:< LoginForm/>
        },
        {
          path: "posts",
          element:< Posts/>
        },
        {
          path: "posts/my",
          element:< MyPosts/>
        },
        {
          path:"posts/my/create",
          element: <CreateForm />
        }
      ]
    }
  ])
   
  return (
    <RouterProvider router={routes}/>
  )
}
