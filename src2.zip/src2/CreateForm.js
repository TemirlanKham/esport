import { useState } from "react";
import { createPost } from './api';
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function CreateForm({ user, categories }) {
    const navigate = useNavigate();

    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [categoryId, setCategoryId] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        const { success, data } = await createPost({ title, content, categoryId, userId: user.id });
        if (success) {
            navigate("/posts/my", { state: { message: data } });
        } else {
            toast(data);
        }
    }

    return (
        <div>
            <h2>Create New Post</h2>
            <form onSubmit={handleSubmit}>
                <label>Title:</label><br />
                <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} /><br />
                <label>Content:</label><br />
                <textarea value={content} onChange={(e) => setContent(e.target.value)} /><br />
                <label>Category:</label><br />
                <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                    <option value="">Select category</option>
                    {categories.map(category => (
                        <option key={category.id} value={category.id}>{category.name}</option>
                    ))}
                </select><br />
                <button type="submit">Create</button>
            </form>
            <ToastContainer />
        </div>
    )
}

export default CreateForm;
