import { useState } from "react";
import {doLogin} from './api';
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function LoginForm(){

    const navigate = useNavigate();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) =>{
        e.preventDefault();

        const {success, data} = await doLogin(email, password);
        if(success){
            navigate("/posts/my", {state: {message: data}});
        }
        else{
            toast(data);
        }
    }

    return(
        <div className="container form-group mt-5">
            <h2> Login Form  </h2>
            <form onSubmit={handleSubmit}>

                <div className="form-group">
                    <label for="email2">Email address</label><br/>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-control" id="email2" aria-describedby="emailHelp" placeholder="Enter email"/>
                </div><br/>
                
                <div className="form-group">
                    <label for="password2">Password</label><br/>
                    <input type="password"  value={password} onChange={(e) => setPassword(e.target.value)} className="form-control" id="password2" placeholder="Password"/>
                </div><br/>
                    <button type="submit" className="btn btn-info"> Login </button>
            </form>
        </div>
    )
}

export default LoginForm;
