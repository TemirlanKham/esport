import axios from "axios";

const authHeader = () =>{
    const user = JSON.parse(localStorage.getItem("user"));

    if (user && user.token){
        return {Authorization: 'Bearer ' + user.token}
    }
    else{
        return {};
    }
}

export const doLogin = async (email, password) =>{
    try{
        const response = await axios.post('http://localhost:3009/login',
        {
            email: email,
            password: password
        },
        { headers: authHeader() }
    )

    localStorage.setItem("user", JSON.stringify(response.data));
    return {success: true, data: "User was logged in "}
    }
    catch(error){
        return {success: false, data: error.response.data.error}
    }
}

export const doRegister = async (email, password, username) => {
    try {
        const response = await axios.post('http://localhost:3009/register',
            {
                email: email,
                password: password,
                username: username
            },
            { headers: authHeader() }
        );

        localStorage.setItem("user", JSON.stringify(response.data));
        return { success: true, data: "User was registered" };
    } catch (error) {
        return { success: false, data: error.response.data.error };
    }
}

export const createPost = async (title, content, categoryId) => {
    try {
        const response = await axios.post('http://localhost:3009/posts/create',{
                title: title,
                content:content,
                categoryId:categoryId
            },
            { headers: authHeader() }
        );
        localStorage.setItem("post", JSON.stringify(response.data))
        return { success: true, data: 'Post created successfully' };
    } catch (error) {
        return { success: false, data: error.response.data.error };
    }
}

export const updatePost = async (postId, title, content, categoryId) => {
    try {
        const response = await axios.put( `http://localhost:3009/posts/${postId}/edit`,
            {
                title: title,
                content: content,
                categoryId: categoryId
            },
            { headers: authHeader() }
        );
        localStorage.setItem("post", JSON.stringify(response.data))
        return { success: true, data: 'Post updated successfully' };
    } catch (error) {
        return { success: false, data: error.response.data.error };
    }
}


export const getOnePost = async (postId) => {
    try {
        const response = await axios.get(`http://localhost:3009/posts/${postId}`);
        return { success: true, data: response.data };
    } catch (error) {
        return { success: false, data: error.response.data.error };
    }
}


export const getAllCategories = async () =>{
    try{
        const response = await axios.get('http://localhost:3009/categories')
        return {success: true, data: response.data};
    }
    catch(error){
        return{ success: false, data: error.response.data.error }
    }
}

export const deletePost = async (postId) => {
    try {
        await axios.delete(`http://localhost:3009/posts/${postId}`,
            { headers: authHeader() }
        );
        return { success: true, data: 'Post deleted successfully' };
    } catch (error) {
        return { success: false, data: error.response.data.error };
    }
};


export const getAllPosts = async () =>{
    try{
        const response = await axios.get('http://localhost:3009/posts')
        return {success: true, data: response.data};
    }
    catch(error){
        return {success: false, data: error.response.data.error}
    }
}

export const getMyPosts = async ()=>{
    try{
        const response = await axios.get('http://localhost:3009/privatePosts',
            {headers: authHeader()}
        )
    return {success: true, data: response.data}
    }

    catch(error){
        return {success: false, data: error.response.data.error};
    }
}