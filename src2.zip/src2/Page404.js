import { Link } from "react-router-dom"

export default function Page404(){
    return(
        <div>
            <p>404 ondai narse jok paraksha tabylmady</p>
            <Link  to="/posts/my" > Basty bet</Link>
        </div>
    )
}