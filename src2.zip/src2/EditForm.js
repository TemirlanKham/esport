import { useState, useEffect } from "react";
import { getOnePost, updatePost } from "./api";
import { useNavigate, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';

function EditForm({ user }) {
    const navigate = useNavigate();
    const params = useParams();

    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [categoryId, setCategoryId] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            const { success, data } = await getOnePost(params.postId);
            if (success) {
                setTitle(data.title);
                setContent(data.content);
                setCategoryId(data.categoryId);
            } else {
                toast(data);
            }
        };
        fetchPost();
    }, [params.postId]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const { success, data } = await updatePost(params.postId, { title, content, categoryId });
        if (success) {
            navigate("/posts/my", { state: { message: data } });
        } else {
            toast(data);
        }
    }

    return (
        <div>
            <h2>Edit Post</h2>
            <form onSubmit={handleSubmit}>
                <label>Title:</label><br />
                <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} /><br />
                <label>Content:</label><br />
                <textarea value={content} onChange={(e) => setContent(e.target.value)} /><br />
                <label>Category:</label><br />
                <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                    <option value="">Select category</option>
                    {/* {categories.map(category => (
                        <option key={category.id} value={category.id}>{category.name}</option>
                    ))} */}
                </select><br />
                <button type="submit">Save</button>
            </form>
            <ToastContainer />
        </div>
    )
}

export default EditForm;
