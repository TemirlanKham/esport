import 'bootstrap/dist/css/bootstrap.min.css';
import { useEffect, useState } from 'react';
import { getAllPosts } from './api';
import { Link } from 'react-router-dom';
import { Outlet, useNavigate } from 'react-router';


export default function Posts(){

    const [posts, setPosts] = useState([]);

    useEffect(() => {
        const loadPosts = async () => {
            const {success, data } = await getAllPosts();
            if(success){
                setPosts(data);
            }
        }
        loadPosts();
    }, []);

    return(
        <div className='container form-group mt-5'>
            <ul className="list-group list-group-horizontal">
               {
                posts.map((post) => {
                    return (
                        <div key={post.id}>
                            <li class="list-group-item">
                               <Link to={'/posts/' + post.id}>
                                {post.title}    
                            </Link> </li>
                            <p>{post.content}</p>
                        </div>
                    )
                })
            }
            <div>
                <Outlet/>
            </div>
            
            </ul>
        </div>
    )
}