// MyPosts.js
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getMyPosts, deletePost, createPost } from './api';
import { toast } from 'react-toastify';

export default function MyPosts() {
    const navigate = useNavigate();
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        const loadPosts = async () => {
            const { success, data } = await getMyPosts();
            if (success) {
                setPosts(data);
            } else {
                navigate("/login", { state: { message: data } });
            }
        };
        loadPosts();
    }, []);

    const handleDeletePost = async (postId) => {
        const { success, data } = await deletePost(postId);
        if (success) {
            setPosts(posts.filter((post) => post.id !== post.postId));
        } else {
            navigate('/posts/my', {state: {message: data}})
        }
    };

    const handleCreatePost = async(postId) =>{
        const {success, data} = await createPost(postId);
        if(success){
            setPosts(posts.filter((post) => post.id !== postId));
        }
        else{
            navigate('posts/my', {state: {message: data}})
        }
    }

    // const handleClick = async (goodId) =>{
    //     const response = await deleteGood(goodId);
    //     navigate("/langs",{ state: {message: response.name +" deleted" , title:" Course was deleted..."} });
    // }
   
    return (
        <div className='container form-group mt-5'>
            <h2>Profile</h2>
            <h3>My Posts</h3>
            {posts.map((post) => (
             <div key={post.id}>
                <h4>{post.title}</h4>
                <p>{post.content}</p>
                <button onClick={() => handleDeletePost(post.id)}   >Delete</button>
                <Link to={`/posts/${post.id}/edit`}><button>Edit</button></Link>
            </div>
            ))}

            <button ><Link to={'posts/create'}>ADD NEW LIST</Link></button>
            <button><Link to="/posts">ALL POSTS</Link></button>
        </div>
    );
}
