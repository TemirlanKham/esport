import { useEffect, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router";
import { ToastContainer, toast } from "react-toastify";


export default function Navigation(){

    const location = useLocation();
    const navigate = useNavigate();

    const [hasToken, setHasToken] = useState(false);

    useEffect(() =>{
        if(location.state){
            toast(location.state.message);
            location.state =  null;
        }

        const  user = JSON.parse(localStorage.getItem("user"));
        if(user){
            setHasToken(true);
        }
    }, [location])

    const logout = () =>{
        localStorage.removeItem("user");
        navigate("/login");
        window.location.reload();
    };

    return(
        <div className=' container form-group mt-5'>
            <ToastContainer/>
            <div>
                i am the Navigation bar
                {
                    hasToken ? (
                        <button  className="btn btn-dark" onClick={logout}> Logout </button>
                    ) : (
                        <button  className="btn btn-dark" onClick={() =>{navigate("/register")}}> Register </button>
                    )
                }
               <button  className="btn btn-dark" onClick={()=> {navigate("/posts/my")}}> prfofile bet </button>
            </div>
            <Outlet/>
        </div>
    )
}